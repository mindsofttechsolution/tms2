import React, { useState } from 'react';
import { LayoutDashboard, Calculator, CalendarDays, Bot, Menu, GraduationCap, User, Settings, LogOut, X, Clock, FileText, Users } from 'lucide-react';
import { AppView } from '../types';

interface LayoutProps {
  currentView: AppView;
  setView: (view: AppView) => void;
  teacherName: string;
  teacherClass: string;
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ currentView, setView, teacherName, teacherClass, children }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  
  const handleMenuClick = (view: AppView) => {
    setView(view);
    setIsMenuOpen(false);
  };

  const NavItem = ({ view, icon: Icon, label }: { view: AppView; icon: any; label: string }) => {
    const isActive = currentView === view;
    return (
      <button
        onClick={() => setView(view)}
        className={`flex flex-col items-center justify-center w-full py-3 transition-colors duration-200 
          ${isActive ? 'text-indigo-600' : 'text-slate-400 hover:text-slate-600'}`}
      >
        <Icon size={24} strokeWidth={isActive ? 2.5 : 2} />
        <span className="text-[10px] mt-1 font-medium">{label}</span>
      </button>
    );
  };

  return (
    <div className="flex flex-col h-screen bg-slate-50 text-slate-900 overflow-hidden font-sans relative">
      {/* Mobile Menu Overlay */}
      {isMenuOpen && (
        <div className="absolute inset-0 z-50 flex">
          <div 
            className="absolute inset-0 bg-black/40 backdrop-blur-sm transition-opacity animate-in fade-in" 
            onClick={() => setIsMenuOpen(false)}
          />
          <div className="relative w-72 bg-white h-full shadow-2xl p-6 flex flex-col gap-4 animate-in slide-in-from-left duration-300">
              <button 
                onClick={() => setIsMenuOpen(false)}
                className="absolute top-4 right-4 p-2 hover:bg-slate-100 rounded-full text-slate-400"
              >
                <X size={20} />
              </button>

              <div className="flex items-center gap-3 mb-6 border-b border-slate-100 pb-6 mt-4">
                  <div className="w-12 h-12 bg-indigo-50 rounded-full flex items-center justify-center text-indigo-600 font-bold text-xl uppercase">
                      {teacherName.split(' ').map(n => n[0]).join('').substring(0, 2)}
                  </div>
                  <div>
                      <h2 className="font-bold text-slate-800">{teacherName}</h2>
                      <p className="text-xs text-slate-400">Class Teacher: {teacherClass}</p>
                  </div>
              </div>
              
              <button 
                onClick={() => handleMenuClick(AppView.STUDENTS)}
                className={`flex items-center gap-3 p-3 rounded-xl font-medium transition-colors ${currentView === AppView.STUDENTS ? 'bg-indigo-50 text-indigo-600' : 'text-slate-600 hover:bg-slate-50'}`}
              >
                  <Users size={20} /> My Class ({teacherClass})
              </button>

              <button 
                onClick={() => handleMenuClick(AppView.DOCUMENTS)}
                className={`flex items-center gap-3 p-3 rounded-xl font-medium transition-colors ${currentView === AppView.DOCUMENTS ? 'bg-indigo-50 text-indigo-600' : 'text-slate-600 hover:bg-slate-50'}`}
              >
                  <FileText size={20} /> My Documents
              </button>
              
              <button 
                onClick={() => handleMenuClick(AppView.SCHEDULE)}
                className={`flex items-center gap-3 p-3 rounded-xl font-medium transition-colors ${currentView === AppView.SCHEDULE ? 'bg-indigo-50 text-indigo-600' : 'text-slate-600 hover:bg-slate-50'}`}
              >
                  <Clock size={20} /> Time Table
              </button>

              <button 
                onClick={() => handleMenuClick(AppView.GPA)}
                className={`flex items-center gap-3 p-3 rounded-xl font-medium transition-colors ${currentView === AppView.GPA ? 'bg-indigo-50 text-indigo-600' : 'text-slate-600 hover:bg-slate-50'}`}
              >
                  <Calculator size={20} /> Marks & GPA
              </button>

              <button 
                onClick={() => handleMenuClick(AppView.SETTINGS)}
                className={`flex items-center gap-3 p-3 rounded-xl font-medium transition-colors ${currentView === AppView.SETTINGS ? 'bg-indigo-50 text-indigo-600' : 'text-slate-600 hover:bg-slate-50'}`}
              >
                  <Settings size={20} /> Settings
              </button>
              
              <div className="flex-1" />

              <button className="flex items-center gap-3 text-red-500 p-3 hover:bg-red-50 rounded-xl font-medium transition-colors">
                  <LogOut size={20} /> Sign Out
              </button>

              <div className="border-t border-slate-100 pt-4 mt-2 text-center">
                 <p className="text-[10px] text-slate-400">Developed by</p>
                 <p className="text-xs font-bold text-slate-600">Mindsoft Tech Solution</p>
                 <a href="mailto:mindsofttechsolution@gmail.com" className="text-[9px] text-indigo-400 block mt-0.5">mindsofttechsolution@gmail.com</a>
              </div>
          </div>
        </div>
      )}

      {/* Top Header */}
      <header className="bg-indigo-950 text-white p-4 shadow-md z-20 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <div className="bg-white/10 p-2 rounded-lg backdrop-blur-sm">
            <GraduationCap size={24} className="text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-tight">Smart TMS</h1>
            <p className="text-xs text-indigo-200">Teacher Management System</p>
          </div>
        </div>
        <button 
          onClick={() => setIsMenuOpen(true)}
          className="p-2 hover:bg-indigo-900 rounded-full transition-colors"
        >
           <Menu size={24} className="text-white" />
        </button>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto relative z-10 scrollbar-hide">
        {children}
      </main>

      {/* Bottom Navigation */}
      <nav className="bg-white border-t border-slate-200 shrink-0 pb-safe shadow-lg">
        <div className="flex justify-around items-center max-w-md mx-auto">
          <NavItem view={AppView.DASHBOARD} icon={LayoutDashboard} label="Home" />
          <NavItem view={AppView.STUDENTS} icon={Users} label="Class" />
          <NavItem view={AppView.DOCUMENTS} icon={FileText} label="Docs" />
          <NavItem view={AppView.AI_ASSIST} icon={Bot} label="Assistant" />
        </div>
      </nav>
    </div>
  );
};

export default Layout;