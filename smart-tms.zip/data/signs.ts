import { LeaveRecord, Task, TimeTableItem, DocumentItem, Student } from '../types';

export const LEAVE_HISTORY: LeaveRecord[] = [
  {
    id: 'l1',
    type: 'Casual',
    startDate: '2023-10-05',
    endDate: '2023-10-05',
    days: 1,
    status: 'Approved',
    reason: 'Personal family matter',
    approvedBy: 'Mr. Wijesinghe (Principal)'
  },
  {
    id: 'l2',
    type: 'Medical',
    startDate: '2023-11-12',
    endDate: '2023-11-14',
    days: 3,
    status: 'Approved',
    reason: 'Viral Fever',
    approvedBy: 'Mrs. Perera (VP)'
  },
  {
    id: 'l3',
    type: 'Duty',
    startDate: '2023-12-01',
    endDate: '2023-12-01',
    days: 1,
    status: 'Pending',
    reason: 'Zonal Sports Meet Coordinator',
  }
];

export const getGradeDetails = (marks: number) => {
  if (marks >= 85) return { letter: 'A+', point: 4.0 };
  if (marks >= 75) return { letter: 'A', point: 4.0 };
  if (marks >= 70) return { letter: 'A-', point: 3.7 };
  if (marks >= 65) return { letter: 'B+', point: 3.3 };
  if (marks >= 60) return { letter: 'B', point: 3.0 };
  if (marks >= 55) return { letter: 'B-', point: 2.7 };
  if (marks >= 50) return { letter: 'C+', point: 2.3 };
  if (marks >= 45) return { letter: 'C', point: 2.0 };
  if (marks >= 40) return { letter: 'C-', point: 1.7 };
  if (marks >= 35) return { letter: 'D', point: 1.0 };
  return { letter: 'E', point: 0.0 };
};

export const MOCK_PERFORMANCE_DATA = [
  { subject: 'Math', avg: 78 },
  { subject: 'Science', avg: 85 },
  { subject: 'English', avg: 65 },
  { subject: 'History', avg: 90 },
  { subject: 'IT', avg: 88 },
];

export const MOCK_TASKS: Task[] = [
  { id: '1', title: 'Submit Grade 10 Math Marks', completed: false, dueDate: 'Today, 2:00 PM' },
  { id: '2', title: 'Department Meeting Preparation', completed: false, dueDate: 'Tomorrow, 9:00 AM' },
  { id: '3', title: 'Review Science Fair Proposals', completed: true, dueDate: 'Yesterday' },
  { id: '4', title: 'Parent-Teacher Conf. Notes', completed: false, dueDate: 'Friday' },
];

export const MOCK_TIMETABLE: TimeTableItem[] = [
  { id: 't1', day: 'Monday', startTime: '07:45', endTime: '08:25', subject: 'Mathematics', grade: '10-A', room: 'Hall 1', color: 'bg-indigo-100 text-indigo-700 border-indigo-200' },
  { id: 't2', day: 'Monday', startTime: '08:25', endTime: '09:05', subject: 'Science', grade: '11-B', room: 'Lab 2', color: 'bg-emerald-100 text-emerald-700 border-emerald-200' },
  { id: 't3', day: 'Monday', startTime: '09:05', endTime: '09:45', subject: 'Free Period', grade: '-', room: 'Staff Room', color: 'bg-slate-100 text-slate-500 border-slate-200' },
  { id: 't4', day: 'Tuesday', startTime: '07:45', endTime: '08:25', subject: 'Mathematics', grade: '10-C', room: 'Hall 3', color: 'bg-indigo-100 text-indigo-700 border-indigo-200' },
  { id: 't5', day: 'Tuesday', startTime: '10:05', endTime: '10:45', subject: 'History', grade: '9-A', room: 'Hall 4', color: 'bg-amber-100 text-amber-700 border-amber-200' },
  { id: 't6', day: 'Wednesday', startTime: '11:25', endTime: '12:05', subject: 'Science Practical', grade: '11-B', room: 'Lab 1', color: 'bg-purple-100 text-purple-700 border-purple-200' },
];

export const MOCK_DOCUMENTS: DocumentItem[] = [
  { id: 'd1', title: 'Appointment Letter', category: 'Appointment', date: '2018-01-15', imageUrl: '' },
  { id: 'd2', title: 'PGDE Certificate', category: 'Certificates', date: '2020-05-20', imageUrl: '' },
];

export const MOCK_STUDENTS: Student[] = [
  { id: 's1', indexNo: '10234', name: 'Amara Perera', parentName: 'Mr. Sunil Perera', contactNumber: '0771234567', gender: 'Female' },
  { id: 's2', indexNo: '10235', name: 'Kasun Silva', parentName: 'Mrs. Nirmala Silva', contactNumber: '0719876543', gender: 'Male' },
  { id: 's3', indexNo: '10236', name: 'Thenuka Dias', parentName: 'Mr. Jagath Dias', contactNumber: '0765551122', gender: 'Male' },
  { id: 's4', indexNo: '10237', name: 'Binuri Fernando', parentName: 'Mrs. Kanthi Fernando', contactNumber: '0703334444', gender: 'Female' },
];