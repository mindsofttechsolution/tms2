import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const SYSTEM_INSTRUCTION = `You are a highly efficient School Administrative Assistant and Teaching Aide.
Your goal is to assist teachers with their daily tasks.
- If asked to write a letter (e.g., leave request, permission letter), draft a professional and polite letter.
- If asked about student performance, offer general pedagogical advice on how to improve grades or handle classroom behavior.
- If a user provides an image of a handwritten note or document, transcribe or summarize it.
- You can help generate exam questions or lesson plan outlines.
- Be formal yet approachable.`;

export const chatWithGemini = async (message: string, base64Image?: string) => {
  try {
    const modelId = 'gemini-3-pro-preview';
    
    let contents: any = { role: 'user', parts: [] };
    
    if (base64Image) {
      contents.parts.push({
        inlineData: {
          mimeType: 'image/jpeg', 
          data: base64Image
        }
      });
    }
    
    contents.parts.push({ text: message });

    const response = await ai.models.generateContent({
      model: modelId,
      contents: [contents],
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
      }
    });

    return response.text;
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};